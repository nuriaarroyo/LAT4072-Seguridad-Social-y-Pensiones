# Comentarios de resultados — Primera tarea larga

## I) ISR 2026 + Seguridad Social (LSS 1997) + INFONAVIT
- Observaciones sobre ISR vs ingreso:
- Observaciones sobre SS vs ingreso:
- Proporción SS / SBC y qué seguros pesan más:
- Notas sobre topes (UMA) y sensibilidad:

## II) LSS 1997 — tasa de reemplazo y ahorro voluntario objetivo
- RR para edad x y salario y:
- Tasa voluntaria requerida para RR objetivo:
- Sensibilidad RR a voluntaria:
- Comentarios sobre supuestos (rendimiento, inflación, densidad, etc.):

## IV) LSS 1973 — RR por edad de jubilación (60–65)
- Comparación 60 vs 65:
- Forma de la curva RR(edad):
- Conclusiones:
