Aquí se guardarán automáticamente las gráficas si activas el checkbox en la app.
